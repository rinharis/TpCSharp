INSERT INTO utilisateur VALUES (1,'df','df','Fargis','Denis',0,NULL,'1975-09-19',NULL,78140,NULL);
INSERT INTO utilisateur VALUES (2,'dj','dj','Fanael','Julie',1,NULL,NULL,NULL,NULL,NULL);
INSERT INTO utilisateur VALUES (3,'ip','ip','Iaris','Paul',0,NULL,NULL,NULL,NULL,NULL);
COMMIT;

INSERT INTO compte VALUES (12,'Compte Courant',250.00,NULL,NULL,1);
INSERT INTO compte VALUES (13,'Compte Courant',1500.00,100.00,NULL,2);
INSERT INTO compte VALUES (14,'Compte Courant',350.00,50.00,NULL,3);
INSERT INTO compte VALUES (15,'Livret A',9950.00,NULL,0.10,1);
INSERT INTO compte VALUES (16,'Compte Remunéré',500.00,NULL,0.30,2);
COMMIT;

INSERT INTO operation VALUES (1,'Virement',500,'2014-12-31 23:00:00',15);
INSERT INTO operation VALUES (2,'Retrait',-500,'2014-12-31 23:00:00',12);
INSERT INTO operation VALUES (3,'Transaction avec le comte 12',-50,'2015-02-13 13:10:52',15);
INSERT INTO operation VALUES (4,'Transaction avec le comte 15',50,'2015-02-13 13:10:52',12);