-- Drop tables if exists. Keep order
DROP TABLE IF EXISTS operation;
DROP TABLE IF EXISTS compte;
DROP TABLE IF EXISTS utilisateur;

CREATE TABLE utilisateur (
  id INTEGER IDENTITY PRIMARY KEY,
  login VARCHAR(120) NOT NULL,
  password VARCHAR(120) NOT NULL,
  nom VARCHAR(120),
  prenom VARCHAR(120),
  sex INTEGER,
  derniereConnection TIMESTAMP,
  dateDeNaissance DATE,
  adresse VARCHAR(500),
  codePostal INTEGER,
  telephone VARCHAR(20)
);

CREATE TABLE compte (
  id INTEGER IDENTITY PRIMARY KEY,
  libelle VARCHAR(250),
  solde DECIMAL(10,2),
  decouvert DECIMAL(10,2),
  taux DECIMAL(5,2),
  utilisateurId INTEGER NOT NULL,  
  FOREIGN KEY (utilisateurId) REFERENCES utilisateur (id) ON DELETE NO ACTION ON UPDATE NO ACTION
);

CREATE TABLE operation (
  id INTEGER IDENTITY PRIMARY KEY,
  libelle VARCHAR(250),
  montant DECIMAL(10,2),
  date TIMESTAMP,
  compteId INTEGER NOT NULL,
  FOREIGN KEY (compteId) REFERENCES compte (id) ON DELETE NO ACTION ON UPDATE NO ACTION
);